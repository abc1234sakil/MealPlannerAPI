# Meal Planner API
This API allows users to plan meals, track calories, get recipe suggestions, and generate a shopping list.

### Endpoints
1. `/meal-planner` - Get a meal plan based on dietary preferences.
2. `/calorie-tracker` - Track daily calorie intake.
3. `/recipe-suggestions` - Get recipe suggestions based on diet.
4. `/shopping-list` - Generate a shopping list for the planned meals.
