# main.py

from flask import Flask, jsonify, request

app = Flask(__name__)

# ১. Meal Planning Endpoint
@app.route('/meal-planner', methods=['POST'])
def meal_planner():
    user_data = request.get_json()
    diet_preference = user_data.get("diet", "balanced")
    meals = {"breakfast": "Oatmeal", "lunch": "Grilled Chicken Salad", "dinner": "Steamed Vegetables"}
    return jsonify({"meal_plan": meals, "diet_preference": diet_preference})

# ২. Calorie Tracking Endpoint
@app.route('/calorie-tracker', methods=['POST'])
def calorie_tracker():
    user_data = request.get_json()
    calories = user_data.get("calories", 2000)
    return jsonify({"message": f"Your target calorie intake is {calories} calories per day."})

# ৩. Recipe Suggestions Endpoint
@app.route('/recipe-suggestions', methods=['POST'])
def recipe_suggestions():
    user_data = request.get_json()
    diet = user_data.get("diet", "balanced")
    recipes = ["Grilled Chicken", "Veggie Stir-fry", "Quinoa Salad"]
    return jsonify({"recipes": recipes, "diet": diet})

# ৪. Shopping List Generator Endpoint
@app.route('/shopping-list', methods=['POST'])
def shopping_list():
    user_data = request.get_json()
    meals = user_data.get("meals", [])
    shopping_list = {"Vegetables": ["Tomato", "Broccoli"], "Protein": ["Chicken", "Tofu"], "Grains": ["Rice"]}
    return jsonify({"shopping_list": shopping_list})

if __name__ == '__main__':
    app.run(debug=True)
    